// Copyright Epic Games, Inc. All Rights Reserved.

#include "TPSProject.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TPSProject, "TPSProject" );
