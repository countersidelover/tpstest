// Fill out your copyright notice in the Description page of Project Settings.


#include "Column.h"

Column::Column()
{
}

Column::~Column()
{
}
