#include "EnemyFSM.h"
#include "Enemy.h"
#include <Kismet/GameplayStatics.h>
#include "TPSProject.h"
#include <Components/CapsuleComponent.h>
#include "MeteorBomb.h"  // AMeteorBomb ����
#include "TempMan.h"  // ATempMan ����

// Sets default values for this component's properties
UEnemyFSM::UEnemyFSM()
{
    PrimaryComponentTick.bCanEverTick = true;
}

// Called when the game starts
void UEnemyFSM::BeginPlay()
{
    Super::BeginPlay();

    if (!target)
    {
        auto actor = UGameplayStatics::GetActorOfClass(GetWorld(), ATempMan::StaticClass());
        target = Cast<ATempMan>(actor);
    }
    me = Cast<AEnemy>(GetOwner());
}

// Called every frame
void UEnemyFSM::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    switch (mState)
    {
    case EEnemyState::Idle:
        IdleState();
        break;
    case EEnemyState::Move:
        MoveState();
        break;
    case EEnemyState::Attack:
        AttackState();
        break;
    case EEnemyState::Damage:
        DamageState();
        break;
    case EEnemyState::Die:
        DieState();
        break;
    case EEnemyState::Meteor:
        MeteorState();
        break;
    }
}

// ��� ����
void UEnemyFSM::IdleState()
{
    currentTime += GetWorld()->DeltaTimeSeconds;
    if (currentTime > idleDelayTime)
    {
        mState = EEnemyState::Meteor;
        currentTime = 0;
    }

    // ���׿� ��ų ��� �ֱ� üũ
    if (currentTime > meteorInterval)
    {
        mState = EEnemyState::Meteor;
        currentTime = 0;
    }
}

// �̵� ����
void UEnemyFSM::MoveState()
{
    if (target)
    {
        FVector destination = target->GetActorLocation();
        FVector dir = destination - me->GetActorLocation();
        me->AddMovementInput(dir.GetSafeNormal());

        if (dir.Size() < attackRange)
        {
            mState = EEnemyState::Attack;
        }
    }
}

// ���� ����
void UEnemyFSM::AttackState()
{
    currentTime += GetWorld()->DeltaTimeSeconds;
    if (currentTime > attackDelayTime)
    {
        UE_LOG(LogTemp, Warning, TEXT("Attack!!!!!"));
        currentTime = 0;
    }

    if (target)
    {
        float distance = FVector::Distance(target->GetActorLocation(), me->GetActorLocation());
        if (distance > attackRange)
        {
            mState = EEnemyState::Move;
        }
    }
}

// �ǰ� ����
void UEnemyFSM::DamageState()
{
    currentTime += GetWorld()->DeltaTimeSeconds;
    if (currentTime > damageDelayTime)
    {
        mState = EEnemyState::Idle;
        currentTime = 0;
    }
}

// ���� ����
void UEnemyFSM::DieState()
{
    FVector P0 = me->GetActorLocation();
    FVector vt = FVector::DownVector * dieSpeed * GetWorld()->DeltaTimeSeconds;
    FVector P = P0 + vt;
    me->SetActorLocation(P);

    if (P.Z < -200.0f)
    {
        me->Destroy();
    }
}

// ���׿� ����
void UEnemyFSM::MeteorState()
{
    // ���׿��� �߻��ϴ� �Լ� ȣ��
    LaunchMeteors();
    mState = EEnemyState::Idle;
}

// �ǰ� �˸� �̺�Ʈ �Լ�
void UEnemyFSM::OnDamageProcess()
{
    hp--;

    if (hp > 0)
    {
        mState = EEnemyState::Damage;
    }
    else
    {
        mState = EEnemyState::Die;
        me->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }
}

void UEnemyFSM::LaunchMeteors()
{
    if (target)
    {
        for (int i = 0; i < 10; ++i)
        {
            FVector randomOffset = FMath::VRand() * 200.0f; // 200.0f �ݰ� �� ���� ������
            FVector targetLocation = target->GetActorLocation() + randomOffset;
            FVector startLocation = me->GetActorLocation() + FMath::VRand() * 300.0f; // ���� ���� ���� ��ġ���� ����
            FTransform transform;
            transform.SetLocation(startLocation);

            AMeteorBomb* meteor = GetWorld()->SpawnActor<AMeteorBomb>(AMeteorBomb::StaticClass(), transform);
            if (meteor)
            {
                meteor->TargetLocation = targetLocation;
            }
        }
    }
}

